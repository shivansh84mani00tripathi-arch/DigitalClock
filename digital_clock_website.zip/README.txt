DIGITAL CLOCK WEBSITE

Open index.html in a browser to test it.
The site uses the supplied images as rotating backgrounds.
The clock uses the device's local time; for India, keep the device time zone set to India/IST.

To publish:
1. Upload all files to a static website host such as GitHub Pages.
2. Keep index.html and the background JPG files in the same folder.

To turn it into an Android app later, this web version can be wrapped as an Android app/PWA.
